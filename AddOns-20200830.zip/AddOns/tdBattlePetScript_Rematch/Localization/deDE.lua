
local L = LibStub('AceLocale-3.0'):NewLocale('tdBattlePetScript_Rematch', 'deDE')
if not L then return end

--[===[@debug@
--[[
--@end-debug@]===]
L["LEVELING_FIELD"] = "Level-Haustier"
L["NO_TEAM_FOR_SCRIPT"] = "Es gibt derzeit keine Teams, die zum Skript passen."
L["NOTES"] = "Dieser Skript-Selektor wird an das Rematch-Team gebunden."
L["Team:"] = "Team: "
L["TITLE"] = "Rematch"
L["WRITE_SCRIPT"] = "Skript schreiben"

--[===[@debug@
--]]
--@end-debug@]===]
