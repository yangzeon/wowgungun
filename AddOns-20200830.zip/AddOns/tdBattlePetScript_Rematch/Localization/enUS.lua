
local L = LibStub('AceLocale-3.0'):NewLocale('tdBattlePetScript_Rematch', 'enUS', true)
if not L then return end

--[===[@debug@
--[[
--@end-debug@]===]
L["LEVELING_FIELD"] = "Leveling slot"
L["NO_TEAM_FOR_SCRIPT"] = "No team matches the script."
L["NOTES"] = "This script selector will be bound to Rematch team."
L["Team:"] = true
L["TITLE"] = "Rematch"
L["WRITE_SCRIPT"] = "Write script"

--[===[@debug@
--]]
--@end-debug@]===]

--[===[@debug@
L["LEVELING_FIELD"] = "Leveling slot"
L["NOTES"] = "This script selector will be bound to Rematch team."
L["TITLE"] = "Rematch"
L["WRITE_SCRIPT"] = "Write script"
L['Team:'] = true
L['NO_TEAM_FOR_SCRIPT'] = 'No team matches the script.'
--@end-debug@]===]
