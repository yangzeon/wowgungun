﻿local _,L = ...

if GetLocale()=="esES" then

end
