
local L = LibStub('AceLocale-3.0'):NewLocale('tdBattlePetScript_Rematch', 'ruRU')
if not L then return end

--[===[@debug@
--[[
--@end-debug@]===]
L["LEVELING_FIELD"] = "Слот для прокачивания"
L["NO_TEAM_FOR_SCRIPT"] = "Нет команд для этого скрипта"
L["NOTES"] = "Этот скрипт будет связан с командой Rematch."
L["Team:"] = "Команда:"
L["TITLE"] = "Rematch"
L["WRITE_SCRIPT"] = "Написать скрипт"

--[===[@debug@
--]]
--@end-debug@]===]
