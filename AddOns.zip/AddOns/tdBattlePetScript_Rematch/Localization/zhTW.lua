
local L = LibStub('AceLocale-3.0'):NewLocale('tdBattlePetScript_Rematch', 'zhTW')
if not L then return end

--[===[@debug@
--[[
--@end-debug@]===]
--[[Translation missing --]]
--[[ L["LEVELING_FIELD"] = ""--]] 
--[[Translation missing --]]
--[[ L["NO_TEAM_FOR_SCRIPT"] = ""--]] 
--[[Translation missing --]]
--[[ L["NOTES"] = ""--]] 
--[[Translation missing --]]
--[[ L["Team:"] = ""--]] 
--[[Translation missing --]]
--[[ L["TITLE"] = ""--]] 
--[[Translation missing --]]
--[[ L["WRITE_SCRIPT"] = ""--]] 

--[===[@debug@
--]]
--@end-debug@]===]
