# [2.13.4](https://github.com/WeakAuras/WeakAuras2/tree/2.13.4) (2019-07-07)

[Full Changelog](https://github.com/WeakAuras/WeakAuras2/compare/2.13.3...2.13.4)

## Highlights

 Bug fix for corrupted custom options 

## Commits

emptyrivers (1):

- delete corrupted custom options (#1435)

